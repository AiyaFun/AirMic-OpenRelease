@echo off
call "%~dp0install_firmware.bat" %*
