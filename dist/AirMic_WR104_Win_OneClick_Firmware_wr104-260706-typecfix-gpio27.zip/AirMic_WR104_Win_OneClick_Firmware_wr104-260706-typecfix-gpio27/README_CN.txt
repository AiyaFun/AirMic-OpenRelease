AirMic WR104 Windows 一键安装固件包

固件版本：
wr104-260706-typecfix-gpio27

使用方法：
1. 在 Windows 电脑上解压整个 zip，不要只打开压缩包内的文件。
2. 用数据线把 AirMic WR104 接到电脑。
3. 双击 ONE_CLICK_INSTALL.bat。
4. 如果电脑上只有一个串口，脚本会自动选择；如果有多个串口，按窗口提示输入编号。
5. 等窗口显示 SUCCESS: Firmware installed. 后再拔线。

注意：
- 这是 64 位 Windows 包。
- 刷写时不要拔掉 USB 线。
- 如果提示找不到 COM 口，通常是 USB 线不是数据线，或 Windows 没装对应 USB 串口驱动。
- 如果 Windows 之前已经配对过 AirMic WR104，刷完后建议在蓝牙设备里先删除 AirMic WR104，再重新配对。
- 本版本第三个键改用 GPIO27，避开 GPIO13 与 Type-C 数据口相关线路冲突。

包内文件：
- ONE_CLICK_INSTALL.bat：推荐双击入口。
- install_firmware.bat：备用双击入口。
- scripts/flash_airmic_wr104.ps1：实际刷写脚本。
- firmware/*.bin：AirMic WR104 固件。
- tools/esptool.exe：Espressif 官方 Windows 烧录工具。

烧录参数：
ESP32, baud 460800, flash mode DIO, flash freq 40m, flash size 4MB
0x1000  bootloader.bin
0x8000  partition-table.bin
0x10000 airmic_wr104_classic_combo.bin
