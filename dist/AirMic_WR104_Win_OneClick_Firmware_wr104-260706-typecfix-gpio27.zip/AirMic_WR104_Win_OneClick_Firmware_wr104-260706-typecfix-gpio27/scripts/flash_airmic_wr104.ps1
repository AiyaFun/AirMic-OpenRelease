param(
    [string]$Port = ""
)

$ErrorActionPreference = "Stop"

$Version = "wr104-260706-typecfix-gpio27"
$Baud = "460800"
$RootDir = Split-Path -Parent $PSScriptRoot
$FirmwareDir = Join-Path $RootDir "firmware"
$ToolsDir = Join-Path $RootDir "tools"
$Esptool = Join-Path $ToolsDir "esptool.exe"
$Bootloader = Join-Path $FirmwareDir "bootloader.bin"
$PartitionTable = Join-Path $FirmwareDir "partition-table.bin"
$AppImage = Join-Path $FirmwareDir "airmic_wr104_classic_combo.bin"
$HashFile = Join-Path $FirmwareDir "SHA256SUMS.txt"

function Write-Step {
    param([string]$Message)
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Fail {
    param([string]$Message)
    Write-Host ""
    Write-Host "FAILED: $Message" -ForegroundColor Red
    exit 1
}

function Assert-File {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        Fail "Missing file: $Path"
    }
}

function Get-SerialPorts {
    $ports = @()

    try {
        $ports = @(Get-CimInstance Win32_SerialPort -ErrorAction SilentlyContinue |
            Where-Object { $_.DeviceID -match '^COM\d+$' } |
            ForEach-Object { $_.DeviceID })
    } catch {
        $ports = @()
    }

    if ($ports.Count -eq 0) {
        try {
            $ports = @(Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -match '\(COM\d+\)' } |
                ForEach-Object {
                    if ($_.Name -match '(COM\d+)') {
                        $Matches[1]
                    }
                })
        } catch {
            $ports = @()
        }
    }

    return @($ports | Sort-Object { [int]($_ -replace '\D', '') } -Unique)
}

function Choose-Port {
    param([string]$RequestedPort)

    if ($RequestedPort) {
        return $RequestedPort.Trim().ToUpperInvariant()
    }

    $ports = @(Get-SerialPorts)
    if ($ports.Count -eq 0) {
        Fail "No COM port found. Plug in AirMic WR104 with a data USB cable, then run this again."
    }

    if ($ports.Count -eq 1) {
        Write-Host "Detected serial port: $($ports[0])"
        return $ports[0]
    }

    Write-Host "Detected multiple serial ports:"
    for ($i = 0; $i -lt $ports.Count; $i++) {
        Write-Host ("  [{0}] {1}" -f ($i + 1), $ports[$i])
    }

    $choice = Read-Host "Type the number to use, or type a COM port such as COM5"
    $choice = $choice.Trim()

    if ($choice -match '^COM\d+$') {
        return $choice.ToUpperInvariant()
    }

    [int]$index = 0
    if ([int]::TryParse($choice, [ref]$index) -and $index -ge 1 -and $index -le $ports.Count) {
        return $ports[$index - 1]
    }

    Fail "Invalid port choice: $choice"
}

function Verify-FirmwareHashes {
    Assert-File $HashFile

    Write-Step "Checking firmware files"
    foreach ($line in Get-Content -LiteralPath $HashFile) {
        $trimmed = $line.Trim()
        if (-not $trimmed) {
            continue
        }

        $parts = $trimmed -split '\s+', 2
        if ($parts.Count -ne 2) {
            Fail "Invalid checksum line: $line"
        }

        $expected = $parts[0].ToLowerInvariant()
        $name = $parts[1].Trim()
        $path = Join-Path $FirmwareDir $name
        Assert-File $path

        $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash.ToLowerInvariant()
        if ($actual -ne $expected) {
            Fail "Checksum mismatch: $name"
        }

        Write-Host "OK $name"
    }
}

function Run-Esptool {
    param([string[]]$Arguments)

    Write-Host ""
    Write-Host ("esptool " + ($Arguments -join " ")) -ForegroundColor DarkGray
    & $Esptool @Arguments
    if ($LASTEXITCODE -ne 0) {
        Fail "esptool exited with code $LASTEXITCODE"
    }
}

Write-Host "AirMic WR104 Windows one-click firmware installer"
Write-Host "Firmware: $Version"

Assert-File $Esptool
Assert-File $Bootloader
Assert-File $PartitionTable
Assert-File $AppImage
Verify-FirmwareHashes

$SelectedPort = Choose-Port $Port
Write-Step "Using serial port $SelectedPort"

$CommonArgs = @(
    "--chip", "esp32",
    "--port", $SelectedPort,
    "--baud", $Baud,
    "--before", "default-reset",
    "--after", "hard-reset"
)

Write-Step "Erasing flash"
Run-Esptool ($CommonArgs + @("erase-flash"))

Write-Step "Writing firmware"
Run-Esptool ($CommonArgs + @(
    "write-flash",
    "-z",
    "--flash-mode", "dio",
    "--flash-freq", "40m",
    "--flash-size", "4MB",
    "0x1000", $Bootloader,
    "0x8000", $PartitionTable,
    "0x10000", $AppImage
))

Write-Host ""
Write-Host "SUCCESS: Firmware installed." -ForegroundColor Green
Write-Host "If Windows already paired with AirMic WR104 before, remove that Bluetooth device and pair it again."
exit 0
