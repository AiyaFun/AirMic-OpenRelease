@echo off
setlocal
chcp 65001 >nul
title AirMic WR104 Firmware Installer

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\flash_airmic_wr104.ps1" %*
set "ERR=%ERRORLEVEL%"

echo.
if "%ERR%"=="0" (
  echo AirMic WR104 firmware install finished.
) else (
  echo AirMic WR104 firmware install failed. Error code: %ERR%
)
echo.
pause
exit /b %ERR%
